create table Customer(
	CustomerId serial primary key,
	FirstName varchar(100) not null,
	LastName varchar(100) not null,
	Email varchar(100) not null,
	Address varchar(100) not null,
	PhonenNum int not null
);