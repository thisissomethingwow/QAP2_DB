create table Books(
	BookId serial primary key,
	BookTitle varchar(100) not null,
	Author varchar(100) not null,
	Genre varchar(100) not null,
	Price decimal(4,2) not null,
	Amount int not null
);