create table Student(
	StudentID serial primary key,
	FirstName varchar(100) not null,
	LastName varchar(100) not null,
	DoB date not null,
	Major varchar(100) not null,
	Email varchar(100) not null
);