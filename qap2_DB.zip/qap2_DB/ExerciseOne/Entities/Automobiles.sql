create table Automobiles(
	VIN serial primary key,
	Make varchar(100) not null,
	Model varchar(100) not null,
	Year int not null,
	OwnerID int not null,
	foreign key(OwnerID) references Owners(OwnerID)
);