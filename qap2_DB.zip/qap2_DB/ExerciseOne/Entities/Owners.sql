create table Owners(
	OwnerID serial primary key,
	FirstName varchar(100) not null,
	LastName varchar(100) not null
);