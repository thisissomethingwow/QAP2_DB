create table OrderInfo(
	OrderInfoId serial primary key,
	OrdersId int not null,
	BookId int not null,
	BookTitle varchar(100) not null,
	-- FullPrice decimal(5,2) not null,
	foreign key(OrdersId) references Orders(OrdersId),
	foreign key(BookId) references Books(BookId),
	foreign key(BookTitle) references Books(BookTitle)
	-- foreign key(FullPrice) references Orders(FullPrice)
);