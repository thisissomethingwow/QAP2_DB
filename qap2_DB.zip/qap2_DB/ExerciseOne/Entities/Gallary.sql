create table Gallary(
	GallaryID serial primary key,
	GallaryName varchar(100) not null
);