create table Artwork(
	ArtworkID serial primary key,
	ArtworkName varchar(100) not null,
	Artist varchar(100) not null,
	GallaryID int not null,
	foreign key(GallaryID) references Gallary(GallaryID)
);