create table Orders(
	OrdersId serial primary key,
	OrderDate date not null,
	ArivalDate date not null,
	FullPrice decimal(5,2) not null,
	BookId int not null,
	CustomerId int not null,
	foreign key(CustomerId) references Customer(CustomerId),
	foreign key(BookId) references Books(BookId)
);