create table Pizza(
	PizzaID serial primary key,
	PizzaName varchar(100) not null,
	Size varchar(100) not null,
	Price decimal(4,2) not null
);