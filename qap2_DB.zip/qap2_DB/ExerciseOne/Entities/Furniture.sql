create table Furniture(
	FurnitureID serial primary key,
	FurnitureName varchar(100) not null
);