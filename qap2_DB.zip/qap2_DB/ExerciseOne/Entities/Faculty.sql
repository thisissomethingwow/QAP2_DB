create table Faculty(
	FacultyID serial primary key,
	FirstName varchar(100) not null,
	LastName varchar(100) not null,
	Department varchar(100) not null,
	Email varchar(100) not null
);