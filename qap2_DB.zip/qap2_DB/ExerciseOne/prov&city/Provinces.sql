create table Province(
	ProvinceID serial primary key,
	ProvinceName varchar(100) not null
);