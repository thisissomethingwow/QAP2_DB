create table Cities(
	CityID serial primary key,
	CityName varchar(100) not null,
	ProvinceID int not null,
	foreign key(ProvinceID) references Province(ProvinceID)
);